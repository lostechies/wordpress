using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;
using DesignByContract;

namespace DesignByContract.Tests.RequireContext
{
    [TestFixture()]
    public class When_Is_GreaterThan
    {
        [Test()]
        [ExpectedException(typeof(PreconditionException), ExpectedMessage = "Int32 object was not greater than 0 when preparing to use denominator value")]
        public void Should_raise_exception_on_when_false()
        {
            int denominator = 0;
            Require<int>.That(denominator).Is.GreaterThan(0).When("preparing to use denominator value");
        }
        [Test()]
        public void Should_not_raise_exception_on_when_true()
        {
            int denominator = 1;
            Require<int>.That(denominator).Is.GreaterThan(0).When("preparing to use denominator value");
        }
    }
    [TestFixture()]
    public class When_IsNot_GreaterThan
    {
        [Test()]
        [ExpectedException(typeof(PreconditionException), ExpectedMessage = "Int32 object was greater than 0 when preparing to use denominator value")]
        public void Should_raise_exception_on_when_false()
        {
            int denominator = 1;
            Require<int>.That(denominator).IsNot.GreaterThan(0).When("preparing to use denominator value");
        }
        [Test()]
        public void Should_not_raise_exception_on_when_true()
        {
            int denominator = 0;
            Require<int>.That(denominator).IsNot.GreaterThan(1).When("preparing to use denominator value");
        }
    }
    [TestFixture()]
    public class When_Is_EqualTo
    {
        [Test()]
        [ExpectedException(typeof(PreconditionException), ExpectedMessage = "Boolean object was not equal to True when checking bool value")]
        public void Should_raise_exception_on_when_false()
        {
            bool val1, val2;
            val1 = false;
            val2 = true;
            Require<bool>.That(val1).Is.EqualTo(val2).When("checking bool value");
        }
        [Test()]
        public void Should_not_raise_exception_on_when_true()
        {
            bool val1, val2;
            val1 = false;
            val2 = false;
            Require<bool>.That(val1).Is.EqualTo(val2).When("checking bool value");
        }
    }
    [TestFixture()]
    public class When_IsNot_EqualTo
    {
        [Test()]
        [ExpectedException(typeof(PreconditionException), ExpectedMessage = "Boolean object was equal to False when checking bool value")]
        public void Should_raise_exception_on_when_false()
        {
            bool val1, val2;
            val1 = false;
            val2 = false;
            Require<bool>.That(val1).IsNot.EqualTo(val2).When("checking bool value");
        }
        [Test()]
        public void Should_not_raise_exception_on_when_true()
        {
            bool val1, val2;
            val1 = false;
            val2 = true;
            Require<bool>.That(val1).IsNot.EqualTo(val2).When("checking bool value");
        }
    }
    [TestFixture()]
    public class When_Is_Null
    {
        [Test()]
        [ExpectedException(typeof(PreconditionException), ExpectedMessage = "String object was not NULL when checking value")]
        public void Should_raise_exception_on_when_false()
        {
            string val1 = "";
            Require<string>.That(val1).Is.Null.When("checking value");
        }
        [Test()]
        public void Should_not_raise_exception_on_when_true()
        {
            string val1 = null;
            Require<string>.That(val1).Is.Null.When("checking value");
        }
    }
    [TestFixture()]
    public class When_IsNot_Null
    {
        [Test()]
        [ExpectedException(typeof(PreconditionException), ExpectedMessage = "Object reference was NULL when checking value")]
        public void Should_raise_exception_on_when_false()
        {
            string val1 = null;
            Require<string>.That(val1).IsNot.Null.When("checking value");
        }
        [Test()]
        public void Should_not_raise_exception_on_when_true()
        {
            string val1 = "";
            Require<string>.That(val1).IsNot.Null.When("checking value");
        }
    }
}
