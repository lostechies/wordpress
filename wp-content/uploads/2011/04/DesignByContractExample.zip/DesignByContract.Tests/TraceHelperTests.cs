using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;

using DesignByContract;

namespace DesignByContract.Tests
{
    [TestFixture()]
    public class When_building_trace_message
    {
        [Test()]
        public void Should_produce_string_with_traceType_prefix()
        {
            string expected;
            string actual;
            expected = "[MyTraceType] Here is the message";
            actual = TraceHelper.BuildTraceMessage("MyTraceType", "Here is the message");
            Assert.AreEqual(expected, actual);
        }
    }

    [TestFixture()]
    public class When_using_TraceAssert
    {
        [Test()]
        public void Should_support_calls_without_traceType()
        {
            TraceHelper.TraceAssert(true, "message");
        }
        [Test()]
        public void Should_support_calls_with_traceType()
        {
            TraceHelper.TraceAssert("traceType", true, "message");
        }
    }
}
