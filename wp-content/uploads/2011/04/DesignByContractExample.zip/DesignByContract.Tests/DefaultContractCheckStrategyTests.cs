using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;
using DesignByContract;

namespace DesignByContract.Tests.DefaultContractCheckStrategyContext
{
    [TestFixture()]
    public class When_using_IsGreaterThan_by_Hashcode
    {
        private IContractCheckStrategy strategy;
        [TestFixtureSetUp()]
        public void TestFixtureSetUp()
        {
            strategy = new DefaultContractCheckStrategy();
        }

        [Test()]
        public void Should_evaluate_true_correctly_with_Decimal()
        {
            decimal first, second;
            first = 5;
            second = 0;

            Assert.IsTrue(strategy.IsGreaterThan(first, second));
        }
        [Test()]
        public void Should_evaluate_true_correctly_with_Integer()
        {
            int first, second;
            first = 5;
            second = 0;

            Assert.IsTrue(strategy.IsGreaterThan(first, second));
        }
        [Test()]
        public void Should_evaluate_false_correctly_with_Decimal()
        {
            decimal first, second;
            first = 0;
            second = 5;

            Assert.IsFalse(strategy.IsGreaterThan(first, second));
        }
        [Test()]
        public void Should_evaluate_false_correctly_with_Integer()
        {
            int first, second;
            first = 0;
            second = 5;

            Assert.IsFalse(strategy.IsGreaterThan(first, second));
        }
    }
}
