using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;

using DesignByContract;

namespace DesignByContract.Tests
{
    [TestFixture()]
    public class When_using_Require_without_assertions
    {
        [TestFixtureSetUp()]
        public void TestFixtureSetUp()
        {
            Check.UseAssertions = false;
        }
        [Test()]
        [ExpectedException(typeof(PreconditionException))]
        public void Should_raise_exception_on_invalid_precondition()
        {
            int numerator;
            int denominator;
            decimal result;
            numerator = 5;
            denominator = 0;
            Check.Require(denominator != 0, "denominator must not be 0");
            result = numerator / denominator;
            Assert.Fail("Check.Require failed assertion");
        }
        [Test()]
        [ExpectedException(typeof(PreconditionException))]
        public void Precondition_check_should_work_without_message()
        {
            int numerator;
            int denominator;
            decimal result;
            numerator = 5;
            denominator = 0;
            Check.Require(denominator != 0);
            result = numerator / denominator;
            Assert.Fail("Check.Require failed assertion");
        }
        [Test()]
        public void Should_not_raise_exception_on_valid_precondition()
        {
            int numerator;
            int denominator;
            numerator = 5;
            denominator = 1;
            Check.Require(denominator > 0, "denominator must be greater that 0");
            Assert.IsTrue(denominator > 0, "Check.Require failed assertion");
        }
    }

    [TestFixture()]
    public class When_using_Require_with_assertions
    {
        [TestFixtureSetUp()]
        public void TestFixtureSetUp()
        {
            Check.UseAssertions = true;
        }
        [Test()]
        public void Should_work_same_as_without_assertions()
        {
            int numerator;
            int denominator;
            numerator = 5;
            denominator = 1;
            Check.Require(denominator > 0, "denominator must be greater that 0");
            Assert.IsTrue(denominator > 0, "Check.Require failed assertion");
        }
    }

    [TestFixture()]
    public class When_using_Ensure_without_assertions
    {
        [TestFixtureSetUp()]
        public void TestFixtureSetUp()
        {
            Check.UseAssertions = false;
        }
        [Test()]
        [ExpectedException(typeof(PostconditionException))]
        public void Should_raise_exception_on_invalid_postcondition()
        {
            int firstAgeInYears;
            int secondAgeInYears;
            decimal ageDifference;
            firstAgeInYears = 10;
            secondAgeInYears = 21;
            ageDifference = firstAgeInYears - secondAgeInYears;
            Check.Ensure(ageDifference > 0, "age difference cannot be negative");
            Assert.Fail("Check.Ensure failed assertion");
        }
        [Test()]
        [ExpectedException(typeof(PostconditionException))]
        public void Postcondition_check_should_work_without_message()
        {
            int firstAgeInYears;
            int secondAgeInYears;
            decimal ageDifference;
            firstAgeInYears = 10;
            secondAgeInYears = 21;
            ageDifference = firstAgeInYears - secondAgeInYears;
            Check.Ensure(ageDifference > 0);
            Assert.Fail("Check.Ensure failed assertion");
        }
        [Test()]
        public void Should_not_raise_exception_on_valid_postcondition()
        {
            int firstAgeInYears;
            int secondAgeInYears;
            decimal ageDifference;
            firstAgeInYears = 10;
            secondAgeInYears = 21;
            ageDifference = Math.Abs(firstAgeInYears - secondAgeInYears);
            Check.Ensure(ageDifference > 0, "age difference cannot be negative");
            Assert.IsTrue(ageDifference > 0, "Check.Ensure failed assertion");
        }
    }

    [TestFixture()]
    public class When_using_Ensure_with_assertions
    {
        [TestFixtureSetUp()]
        public void TestFixtureSetUp()
        {
            Check.UseAssertions = true;
        }
        [Test()]
        public void Should_work_same_as_without_assertions()
        {
            int firstAgeInYears;
            int secondAgeInYears;
            decimal ageDifference;
            firstAgeInYears = 10;
            secondAgeInYears = 21;
            ageDifference = Math.Abs(firstAgeInYears - secondAgeInYears);
            Check.Ensure(ageDifference > 0, "age difference cannot be negative");
            Assert.IsTrue(ageDifference > 0, "Check.Ensure failed assertion");
        }
    }

    [TestFixture()]
    public class When_using_Invariant_without_assertions
    {
        [TestFixtureSetUp()]
        public void TestFixtureSetUp()
        {
            Check.UseAssertions = false;
        }
        [Test()]
        [ExpectedException(typeof(InvariantException))]
        public void Should_raise_exception_on_invalid_invariant_condition()
        {
            int oldValue;
            int currentValue;
            oldValue = 2;
            currentValue = oldValue;
            currentValue = currentValue + 1;
            Check.Invariant(currentValue == oldValue, "value cannot change");
            Assert.Fail("Check.Invariant failed assertion");
        }
        [Test()]
        [ExpectedException(typeof(InvariantException))]
        public void Invariant_condition_check_should_work_without_message()
        {
            int oldValue;
            int currentValue;
            oldValue = 2;
            currentValue = oldValue;
            currentValue = currentValue + 1;
            Check.Invariant(currentValue == oldValue);
            Assert.Fail("Check.Invariant failed assertion");
        }
        [Test()]
        public void Should_not_raise_exception_on_valid_invariant_condition()
        {
            int oldValue;
            int currentValue;
            oldValue = 2;
            currentValue = oldValue;
            currentValue = 2;
            Check.Invariant(currentValue == oldValue, "value cannot change");
            Assert.IsTrue(currentValue == oldValue, "Check.Invariant failed assertion");
        }
    }

    [TestFixture()]
    public class When_using_Invariant_with_assertions
    {
        [TestFixtureSetUp()]
        public void TestFixtureSetUp()
        {
            Check.UseAssertions = true;
        }
        [Test()]
        public void Should_work_same_as_without_assertions()
        {
            int oldValue;
            int currentValue;
            currentValue = 2;
            oldValue = currentValue;
            Check.Invariant(currentValue == oldValue, "value cannot change");
            Assert.IsTrue(currentValue.ToString() == oldValue.ToString(), "Check.Invariant failed assertion");
        }
    }

    [TestFixture()]
    public class When_using_Assert_without_assertions
    {
        [TestFixtureSetUp()]
        public void TestFixtureSetUp()
        {
            Check.UseAssertions = false;
        }
        [Test()]
        [ExpectedException(typeof(AssertionException))]
        public void Should_raise_exception_on_invalid_assert_condition()
        {
            bool checkValue = false;
            Check.Assert(checkValue, "checkValue should be true");
            Assert.Fail("Check.Assert failed assertion");
        }
        [Test()]
        [ExpectedException(typeof(AssertionException))]
        public void Assert_condition_check_should_work_without_message()
        {
            bool checkValue = false;
            Check.Assert(checkValue);
            Assert.Fail("Check.Assert failed assertion");
        }
        [Test()]
        public void Should_not_raise_exception_on_valid_assert_condition()
        {
            bool checkValue = true;
            Check.Assert(checkValue, "checkValue should be true");
            Assert.IsTrue(checkValue, "Check.Assert failed assertion");
        }
    }

    [TestFixture()]
    public class When_using_Assert_with_assertions
    {
        [TestFixtureSetUp()]
        public void TestFixtureSetUp()
        {
            Check.UseAssertions = true;
        }
        [Test()]
        public void Should_work_same_as_without_assertions()
        {
            bool checkValue = true;
            Check.Assert(checkValue, "checkValue should be true");
            Assert.IsTrue(checkValue, "Check.Assert failed assertion");
        }
    }

    [TestFixture()]
    public class When_utilizing_property_UseAssertions
    {
        [SetUp()]
        public void SetUp()
        {
            Check.UseAssertions = false;
        }
        [Test()]
        public void Should_default_to_false()
        {
            Assert.IsFalse(Check.UseAssertions, "Should be false by default");
        }
        [Test()]
        public void Should_be_able_to_hold_true()
        {
            Check.UseAssertions = true;
            Assert.IsTrue(Check.UseAssertions, "Should now be true");
        }
        [Test()]
        public void Should_be_able_to_hold_false()
        {
            Check.UseAssertions = false;
            Assert.IsFalse(Check.UseAssertions, "Should now be false");
        }
    }

    [TestFixture()]
    public class When_utilizing_property_UseExceptions
    {
        [SetUp()]
        public void SetUp()
        {
            Check.UseAssertions = false;
        }
        [Test()]
        public void Should_default_to_false()
        {
            Assert.IsTrue(Check.UseExceptions, "UseExceptions failed");
            Assert.IsFalse(Check.UseAssertions, "UseAssertions failed");
        }
        [Test()]
        public void Should_be_able_to_hold_true()
        {
            Check.UseAssertions = true;
            Assert.IsFalse(Check.UseExceptions, "UseExceptions failed");
            Assert.IsTrue(Check.UseAssertions, "UseAssertions failed");
        }
        [Test()]
        public void Should_be_able_to_hold_false()
        {
            Check.UseAssertions = false;
            Assert.IsTrue(Check.UseExceptions, "UseExceptions failed");
            Assert.IsFalse(Check.UseAssertions, "UseAssertions failed");
        }
    }
}
