using System;
using System.Collections.Generic;
using System.Text;

namespace DesignByContract
{
    /// <summary>
    /// Exception raised when a contract is broken.
    /// Catch this exception type if you wish to differentiate between 
    /// any DesignByContract exception and other runtime exceptions.
    /// </summary>
    public class DesignByContractException : ApplicationException
    {
        protected DesignByContractException()
            : base()
        {
        }
        protected DesignByContractException(string message)
            : base(message)
        {
        }
        protected DesignByContractException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }

    /// <summary>
    /// Exception raised when a precondition fails.
    /// </summary>
    public class PreconditionException : DesignByContractException
    {
        public PreconditionException()
            : base()
        {
        }
        public PreconditionException(string message)
            : base(message)
        {
        }
        public PreconditionException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }

    /// <summary>
    /// Exception raised when a postcondition fails.
    /// </summary>
    public class PostconditionException : DesignByContractException
    {
        public PostconditionException()
            : base()
        {
        }
        public PostconditionException(string message)
            : base(message)
        {
        }
        public PostconditionException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }

    /// <summary>
    /// Exception raised when an invariant fails.
    /// </summary>
    public class InvariantException : DesignByContractException
    {
        public InvariantException()
            : base()
        {
        }
        public InvariantException(string message)
            : base(message)
        {
        }
        public InvariantException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }

    /// <summary>
    /// Exception raised when an assertion fails.
    /// </summary>
    public class AssertionException : DesignByContractException
    {
        public AssertionException()
            : base()
        {
        }
        public AssertionException(string message)
            : base(message)
        {
        }
        public AssertionException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
