using System;
using System.Collections.Generic;
using System.Text;

namespace DesignByContract
{
    /// <summary>
    /// Design By Contract Checks.
    /// 
    /// Each method generates an exception or
    /// a trace assertion statement if the contract is broken.
    /// </summary>
    /// <remarks>
    /// This example shows how to call the Require method.
    /// <code>
    /// public void Test(int x)
    /// {
    /// 	try
    /// 	{
    ///			Check.Require(x > 1, "x must be > 1");
    ///		}
    ///		catch (System.Exception ex)
    ///		{
    ///			Console.WriteLine(ex.ToString());
    ///		}
    ///	}
    /// </code>
    ///
    /// You can direct output to a Trace listener. For example, you could insert
    /// <code>
    /// Trace.Listeners.Clear();
    /// Trace.Listeners.Add(new TextWriterTraceListener(Console.Out));
    /// </code>
    /// 
    /// or direct output to a file or the Event Log.
    /// 
    /// (Note: For ASP.NET clients use the Listeners collection
    /// of the Debug, not the Trace, object and, for a Release build, only exception-handling
    /// is possible.)
    /// 
    /// Source originally ported to VB from sample enterprise project by <see href="http://www.codeproject.com/aspnet/NHibernateBestPractices.asp">Bill McCafferty</see>
    /// For more information on Design By Contract see Billy McCafferty's <see href="http://devlicio.us/blogs/billy_mccafferty/archive/2006/09/22/Design_2D00_by_2D00_Contract_3A00_-A-Practical-Introduction.aspx">blog entry</see> on the matter.
    /// </remarks>
    public sealed class Check
    {
        /// <summary>
        /// Precondition check - should run regardless of preprocessor directives.
        /// </summary>
        public static void Require(bool assertion, string message, Exception inner)
        {
            if (UseAssertions)
            {
                TraceHelper.TraceAssert("Precondition", assertion, message);
            }
            else
            {
                if (!assertion)
                {
                    throw new PreconditionException(message, inner);
                }
            }
        }
        /// <summary>
        /// Precondition check - should run regardless of preprocessor directives.
        /// </summary>
        public static void Require(bool assertion, string message)
        {
            Require(assertion, message, null);
        }
        /// <summary>
        /// Precondition check - should run regardless of preprocessor directives.
        /// </summary>
        public static void Require(bool assertion)
        {
            Require(assertion, "Precondition failed.", null);
        }

        /// <summary>
        /// Postcondition check.
        /// </summary>
        public static void Ensure(bool assertion, string message, Exception inner)
        {
            if (UseAssertions)
            {
                TraceHelper.TraceAssert("Postcondition", assertion, message);
            }
            else
            {
                if (!assertion)
                {
                    throw new PostconditionException(message, inner);
                }
            }
        }
        /// <summary>
        /// Postcondition check.
        /// </summary>
        public static void Ensure(bool assertion, string message)
        {
            Ensure(assertion, message, null);
        }
        /// <summary>
        /// Postcondition check.
        /// </summary>
        public static void Ensure(bool assertion)
        {
            Ensure(assertion, "Postcondition failed.", null);
        }

        /// <summary>
        /// Invariant check.
        /// </summary>
        public static void Invariant(bool assertion, string message, Exception inner)
        {
            if (UseAssertions)
            {
                TraceHelper.TraceAssert("Invariant", assertion, message);
            }
            else
            {
                if (!assertion)
                {
                    throw new InvariantException(message, inner);
                }
            }
        }
        /// <summary>
        /// Invariant check.
        /// </summary>
        public static void Invariant(bool assertion, string message)
        {
            Invariant(assertion, message, null);
        }
        /// <summary>
        /// Invariant check.
        /// </summary>
        public static void Invariant(bool assertion)
        {
            Invariant(assertion, "Invariant failed.", null);
        }

        /// <summary>
        /// Assertion check.
        /// </summary>
        public static void Assert(bool assertion, string message, Exception inner)
        {
            if (UseAssertions)
            {
                TraceHelper.TraceAssert("Assertion", assertion, message);
            }
            else
            {
                if (!assertion)
                {
                    throw new AssertionException(message, inner);
                }
            }
        }
        /// <summary>
        /// Assertion check.
        /// </summary>
        public static void Assert(bool assertion, string message)
        {
            Assert(assertion, message, null);
        }
        /// <summary>
        /// Assertion check.
        /// </summary>
        public static void Assert(bool assertion)
        {
            Assert(assertion, "Assertion failed.", null);
        }

        /// <summary>
        /// Constructor protected.
        /// </summary>
        private Check()
        {
        }
        /// <summary>
        /// Is exception handling being used?
        /// </summary>
        public static bool UseExceptions
        {
            get { return !UseAssertions; }
        }
        /// <summary>
        /// Set this if you wish to use Trace Assert statements 
        /// instead of exception handling. 
        /// (The Check class uses exception handling by default.)
        /// </summary>
        public static bool UseAssertions
        {
            get { return _useAssertions; }
            set { _useAssertions = value; }
        }
        //Are trace assertion statements being used? 
        //Default is to use exception handling.
        private static bool _useAssertions = false;
    }
}
