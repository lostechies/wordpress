using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace DesignByContract
{
    /// <summary>
    /// Class aids in constructing Trace calls.
    /// </summary>
    public class TraceHelper
    {
        /// <summary>
        /// Creates Trace.Assert message.
        /// </summary>
        /// <param name="traceType">Used as prefix to add clarity.</param>
        /// <param name="assertion">Bool expression.</param>
        /// <param name="message">Message for trace.</param>
        /// <returns>Result Ex. [TraceType] This is the trace message</returns>
        public static void TraceAssert(string traceType, bool assertion, string message)
        {
            TraceAssert(assertion, BuildTraceMessage(traceType, message));
        }
        /// <summary>
        /// Creates Trace.Assert message.
        /// </summary>
        /// <param name="assertion">Bool expression.</param>
        /// <param name="message">Message for trace.</param>
        public static void TraceAssert(bool assertion, string message)
        {
            Trace.Assert(assertion, message);
        }

        /// <summary>
        /// Builds trace message with trace type prefix.
        /// </summary>
        /// <param name="traceType"></param>
        /// <param name="message"></param>
        /// <returns>Result Ex. [TraceType] This is the trace message</returns>
        public static string BuildTraceMessage(string traceType, string message)
        {
            if ((traceType != null))
            {
                message = "[" + traceType + "] " + message;
            }

            return message;
        }
    }
}
