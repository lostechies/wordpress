using System;
using System.Collections.Generic;
using System.Text;

namespace DesignByContract
{
    public class DefaultContractCheckStrategy : IContractCheckStrategy
    {
        bool IContractCheckStrategy.IsGreaterThan(object first, object second)
        {
            return first.GetHashCode() > second.GetHashCode();
        }
    }
    public interface IContractCheckStrategy
    {
        bool IsGreaterThan(object first, object second);
    }
}
