using System;
using System.Collections.Generic;
using System.Text;

namespace DesignByContract
{
    public class Ensure<T> : ContractCheck<T>
    {
        protected Ensure(T objTocheck)
            : base(objTocheck)
        {
        }
        public static Ensure<T> That(T objToCheck)
        {
            return new Ensure<T>(objToCheck);
        }

        public override void ThrowException(string message, System.Exception inner)
        {
            throw new PostconditionException(message, inner);
        }
    }
}
