using System;
using System.Collections.Generic;
using System.Text;

namespace DesignByContract
{
    public abstract class ContractCheck<T>
    {
        //internal CheckGreaterThanDelegate checkGreaterThan = DefaultIsGreaterThan;
        protected bool checkFailed = false;
        protected bool isNot = false;
        protected T objectToCheck;
        protected Type typeOfCheckedObject;
        protected string errorMessage;
        protected string messagePrefix;
        protected string messageWhenPart;
        private IContractCheckStrategy _strategy;
        protected ContractCheck(T objToCheck)
        {
            objectToCheck = objToCheck;
            if (objToCheck != null)
            {
                typeOfCheckedObject = objToCheck.GetType();
                messagePrefix = typeOfCheckedObject.Name + " object ";
                SetContractCheckStrategy(objToCheck.GetType());
            }
            else
            {
                messagePrefix = "Object reference ";
            }
        }
        protected void SetContractCheckStrategy(Type typeOfCheckedObject)
        {
            _strategy = new DefaultContractCheckStrategy();
        }
        public ContractCheck<T> Is
        {
            get
            {
                isNot = false;
                return this;
            }
        }
        public ContractCheck<T> IsNot
        {
            get
            {
                isNot = true;
                return this;
            }
        }
        private string GetWas()
        {

            return isNot ? "was" : "was not";
        }
        public ContractCheck<T> Null
        {
            get
            {
                setErrorMessage("NULL");
                return EvaluateAssertion(objectToCheck == null);
            }
        }
        public ContractCheck<T> EqualTo(T obj)
        {
            setErrorMessage("equal to " + obj.ToString());
            return EvaluateAssertion(objectToCheck.Equals(obj));
        }
        public ContractCheck<T> GreaterThan(T obj)
        {
            setErrorMessage("greater than " + obj.ToString());
            return EvaluateAssertion(_strategy.IsGreaterThan(objectToCheck, obj));
        }

        public ContractCheck<T> EvaluateAssertion(bool assertion)
        {
            if (assertion)
            {
                checkFailed = false;
            }
            else
            {
                checkFailed = true;
            }
            checkFailed = isNot ? !checkFailed : checkFailed;
            return this;
        }

        public void When(string message)
        {
            if (checkFailed)
            {
                messageWhenPart = " when " + message;
                ThrowException(messagePrefix + errorMessage + messageWhenPart);
            }
        }

        private void setErrorMessage(string message)
        {
            errorMessage = GetWas() + " " + message;
        }
        public void ThrowException()
        {
            ThrowException(null, null);
        }
        public void ThrowException(string message)
        {
            ThrowException(message, null);
        }
        public abstract void ThrowException(string message, Exception inner);
    }
    //internal delegate bool CheckGreaterThanDelegate(object firstObj, object secondObject);
}
