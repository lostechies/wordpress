using System;
using System.Collections.Generic;
using System.Text;

namespace DesignByContract
{
    public class Require<T> : ContractCheck<T>
    {
        protected Require(T objTocheck)
            : base(objTocheck)
        {
        }
        public static Require<T> That(T objToCheck)
        {
            return new Require<T>(objToCheck);
        }

        public override void ThrowException(string message, System.Exception inner)
        {
            throw new PreconditionException(message, inner);
        }
    }
}
