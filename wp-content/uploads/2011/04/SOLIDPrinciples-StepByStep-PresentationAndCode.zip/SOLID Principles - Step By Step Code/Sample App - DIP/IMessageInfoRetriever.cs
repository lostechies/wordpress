namespace SOLID.SampleApp
{
	public interface IMessageInfoRetriever
	{
		string GetMessageBody();
	}
}