namespace SOLID.SampleApp
{
	public interface IEmailSender
	{
		void SendEmail(string messageBody);
	}
}