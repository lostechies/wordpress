using NUnit.Framework;

namespace AlamoCoders.BDD.Domain.Specs.CurrencySlot_Specs
{
    [TestFixture]
    public class When_a_new_bill_is_being_added_to_the_wallet
    {
        [Test]
        public void should_use_the_monetary_sensor_to_read_the_value_of_the_bill()
        {
            //For the sake of time and the level of this presentation I am not going
            //to talk about Mock objects. Although you would use a mock MonetarySenor 
            //to inject into the CurrencySlot contructor.

            CurrencySlot currencySlot = new CurrencySlot(new MonetarySensor());
            Assert.AreEqual(5m, currencySlot.ReadBill(new Bill(5m)));

        }
    }

}