using NUnit.Framework;
namespace AlamoCoders.BDD.Domain.Specs.CurrencySlot_Specs.MonetarySensor_Spec
{
    [TestFixture]
    public class When_reading_bills
    {
        [SetUp]
        public void SetUpContext()
        {
             
        }

        [Test]
        public void Should_be_able_to_determine_monetary_value()
        {
            MonetarySensor monetarySensor = new MonetarySensor();
            
            Assert.AreEqual(5m, monetarySensor.Read(new Bill(5m)));
        }
    }
}