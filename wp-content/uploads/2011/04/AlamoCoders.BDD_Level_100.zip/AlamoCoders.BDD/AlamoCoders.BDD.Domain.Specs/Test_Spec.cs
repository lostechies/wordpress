using NUnit.Framework;
namespace AlamoCoders.BDD.Domain.Specs.Test_Spec
{
    [TestFixture]
    public class 
        When_this_happens
    {
        [SetUp]
        public void SetUpContext()
        {
             
        }
    }
}