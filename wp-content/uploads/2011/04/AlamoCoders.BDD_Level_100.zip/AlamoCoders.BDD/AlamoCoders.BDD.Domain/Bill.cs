namespace AlamoCoders.BDD.Domain
{
    public class Bill
    {
        private readonly decimal billValue;

        public Bill()
        {
           
        }

        public Bill(decimal billValue)
        {
            this.billValue = billValue;
        }

        public decimal Value
        {
            get { return billValue; }
        }
    }
}