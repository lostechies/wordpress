using System;
using System.Collections.Generic;
using System.Text;

namespace AlamoCoders.BDD.Domain
{
    public class CurrencySlot
    {
        private readonly MonetarySensor monetarySensor;

        public CurrencySlot(MonetarySensor monetarySensor)
        {
            this.monetarySensor = monetarySensor;
        }

        public decimal ReadBill(Bill bill)
        {
            return monetarySensor.Read(bill);
            
        }
    }
}
