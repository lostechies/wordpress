using System;
using System.Collections.Generic;
using System.Text;

namespace AlamoCoders.BDD.Domain
{
    public class MonetarySensor
    {
        public decimal Read(Bill bill)
        {
            return bill.Value;
        }
    }
}
