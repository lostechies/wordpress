</div><!-- end div tabs see header.php -->
<?php switch_to_blog(1); ?>	
	<div id="footer">
		<div class="container_12">
		<div id="footer-widget-area">
				<div class="grid_4">					
					<ul>
					<li><a href="<?php bloginfo('url'); ?>" title="home">Home</a></li>
					<?php wp_list_pages('title_li='); ?>
					<li><a href="http://feeds.feedburner.com/LosTechies" rel="alternate" type="application/rss+xml"><img src="http://www.feedburner.com/fb/images/pub/feed-icon16x16.png" alt="" style="vertical-align:middle;border:0"/></a><a href="http://feeds.feedburner.com/LosTechies"><img src="http://feeds.feedburner.com/~fc/LosTechies?bg=FFFFFF&amp;fg=2E9BD2&amp;anim=1" height="26" width="88" style="vertical-align:middle;border:0"/></a></li>
					</ul>
				</div><!-- #second .widget-area -->
				<div class="grid_4">
					
					<h3>Friends of Pablo</h3>
<ul>
<li><a href="http://tekpub.com" _target="_blank">TekPub</a></li>
<li><a href="http://www.pec.stedwards.edu/" _target="_blank">St. Edward's Professional Education Center</a></li>
<li><a href="http://agilezen.com/" _target="_blank">AgileZen</a></li>
<li><a href="http://virtualaltnet.com/" _target="_blank">Virtual Alt.NET</a></li>
<li><a href="http://europevan.blogspot.com/" _target="_blank">European Virtual Alt.NET</a></li>
<li><a href="http://www.pragprog.com/" _target="_blank">Pragmatic Bookshelf</a></li>
<li><a href="http://www.jetbrains.com/" _target="_blank">JetBrains</a></li>
<li><a href="http://www.visualsvn.com/" _target="_blank">VisualSVN</a></li>
<li><a href="hhttp://www.techsmith.com/camtasia.asp" _target="_blank">TechSmith Camtasia</a></li>
<li><a href="http://www.nhprof.com/" _target="_blank">NHProf</a></li>
<li><a href="http://www.ncover.com/" _target="_blank">NCover</a></li>
</ul>				
				</div><!-- #third .widget-area -->
				<div class="grid_4">
					<?php bloginfo('name'); ?> &copy; '<?php echo date('y'); ?><br />
						<?php bloginfo('description'); ?><br />
				<?php printf( __( 'Proudly powered by <span id="generator-link">%s</span>.', 'twentyten' ), '<a href="http://wordpress.org/" title="' . esc_attr__( 'Semantic Personal Publishing Platform', 'twentyten' ) . '" rel="generator">' . __( 'WordPress', 'twentyten' ) . '</a>' ); ?>
					
				</div><!-- #fourth .widget-area -->
			</div><!-- #footer-widget-area -->		
		
			</div><!-- end div.container_12 -->

	</div><!-- end div#footer -->
		<?php restore_current_blog(); ?>

</script><script type="text/javascript"> 
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script> 
<script type="text/javascript"> 
try {
var pageTracker = _gat._getTracker("UA-1265430-2");
pageTracker._trackPageview();
} catch(err) {}</script> 
 
<script type='text/javascript'>//<![CDATA[
    if (typeof jQuery == 'undefined') {
        document.write(unescape("%3Cscript src='http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.4.2.min.js' type='text/javascript' %3E%3C/script%3E"));
    }//]]></script> 
<script type='text/javascript' language='Javascript' src='http://s1.lqcdn.com/m.min.js?dt=2.3.110202.1'></script> 
<script type='text/javascript' language='Javascript'> if(jQuery.LqmAds)jQuery.LqmAds();</script></form>

<script type='text/javascript' src='/wp-content/plugins/syntaxhighlighter/syntaxhighlighter3/scripts/shCore.js?ver=3.0.83b'></script>
<script type='text/javascript' src='/wp-content/plugins/syntaxhighlighter/syntaxhighlighter3/scripts/shBrushCSharp.js?ver=3.0.83b'></script>
<script type='text/javascript' src='/wp-content/plugins/syntaxhighlighter/syntaxhighlighter3/scripts/shBrushRuby.js?ver=3.0.83b'></script>
<script type='text/javascript' src='/wp-content/plugins/syntaxhighlighter/syntaxhighlighter3/scripts/shBrushJScript.js?ver=3.0.83b'></script>
<script type='text/javascript' src='/wp-content/plugins/syntaxhighlighter/syntaxhighlighter3/scripts/shBrushXml.js?ver=3.0.83b'></script>
<script type='text/javascript' src='/wp-content/plugins/syntaxhighlighter//third-party-brushes/shBrushFSharp.js?ver=3.0.83b'></script>
<script type='text/javascript'>
	(function(){
		var corecss = document.createElement('link');
		var themecss = document.createElement('link');
		var corecssurl = "/wp-content/plugins/syntaxhighlighter/syntaxhighlighter3/styles/shCore.css?ver=3.0.83b";
		if ( corecss.setAttribute ) {
				corecss.setAttribute( "rel", "stylesheet" );
				corecss.setAttribute( "type", "text/css" );
				corecss.setAttribute( "href", corecssurl );
		} else {
				corecss.rel = "stylesheet";
				corecss.href = corecssurl;
		}
		document.getElementsByTagName("head")[0].insertBefore( corecss, document.getElementById("syntaxhighlighteranchor") );
		var themecssurl = "/wp-content/plugins/syntaxhighlighter/syntaxhighlighter3/styles/shThemeDefault.css?ver=3.0.83b";
		if ( themecss.setAttribute ) {
				themecss.setAttribute( "rel", "stylesheet" );
				themecss.setAttribute( "type", "text/css" );
				themecss.setAttribute( "href", themecssurl );
		} else {
				themecss.rel = "stylesheet";
				themecss.href = themecssurl;
		}
		//document.getElementById("syntaxhighlighteranchor").appendChild(themecss);
		document.getElementsByTagName("head")[0].insertBefore( themecss, document.getElementById("syntaxhighlighteranchor") );
	})();
	SyntaxHighlighter.config.strings.expandSource = '+ expand source';
	SyntaxHighlighter.config.strings.help = '?';
	SyntaxHighlighter.config.strings.alert = 'SyntaxHighlighter\n\n';
	SyntaxHighlighter.config.strings.noBrush = 'Can\'t find brush for: ';
	SyntaxHighlighter.config.strings.brushNotHtmlScript = 'Brush wasn\'t configured for html-script option: ';
	SyntaxHighlighter.defaults['gutter'] = false;
    SyntaxHighlighter.defaults['tab-size'] = 2;
    SyntaxHighlighter.defaults['toolbar'] = false;
    SyntaxHighlighter.defaults['wrap-lines'] = false; 
	SyntaxHighlighter.defaults['pad-line-numbers'] = false;
	SyntaxHighlighter.all();
</script>
 
</body>
</html>
