﻿using MVCRequestTesting.Web;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

namespace MVCRequestTesting.IntegrationTesting
{
	[TestFixture]
	public class HomeIndexViewTester
	{
		[Test]
		public void Index_action_should_render_welcome_message()
		{
			var host = TestASPAppHost.GetHostRelativeToAssemblyPath(@"..\..\..\MVCRequestTesting.Web");
			var htmlResult = host.ExecuteMvcUrl("Home/Index", "");
			Assert.That(htmlResult, Text.Contains("<h2>Welcome to ASP.NET MVC!</h2>"));
		}
	}
}